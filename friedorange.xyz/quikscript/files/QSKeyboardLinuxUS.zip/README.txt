Installing FriedOrange's keyboard layouts on Linux

WARNING: manually editing keyboard layouts on Linux can cause problems when
done incorrectly. This may disable the keyboard and even prevent logging in.
To be safe, ensure that you have a way of switching layouts using the mouse 
and that the new layout is not set to default.


1. Naviage to your xkb folder. In recent versions of popular distributions, it 
   is located at /usr/share/X11/xkb.

2. Make a backup copy of the file, xkb/rules/evdev.xml. This (and the following
   two steps) requires elevated (root) access.

3. Copy and paste the contents of "evdev.xml supplement" into the <layoutList> 
   element of your original evdev.xml. 

   You can easily do this by searching within the file for "<layoutList>" and 
   pasting in the new lines directly after it. It is important that the new 
   lines are not pasted in the middle of an existing <layout> element.

4. Copy the other file into the directory X11/xkb/symbols.

5. The new layout should now be visible from the "Layouts" section of your 
   Keyboard Preferences applet, or the equivalent in your distribution/desktop 
   environment. A reboot may be required before being able to see or use it.

6. Some desktop environments will automatically place a button in the "taskbar"
   (or equivalent area of the desktop) to switch between multiple layouts. On
   others like XFCE, this needs to be enabled manually. It is also recommended 
   to enable a key combination for changing layouts; this can usually be done 
   from within the same Keyboard Preferences applet.


For more informantion, see:

https://people.uleth.ca/~daniel.odonnell/Blog/custom-keyboard-in-linuxx11
https://www.maketecheasier.com/change-keyboard-layout-linux/